const $ = (s, root=document) => root.querySelector(s);
const $$ = (s, root=document) => [...root.querySelectorAll(s)];

const clock = $('#clock');
function tick(){
  if(!clock) return;
  const now = new Date();
  clock.textContent = new Intl.DateTimeFormat('zh-CN',{hour:'2-digit',minute:'2-digit',second:'2-digit',hour12:false}).format(now);
}
tick(); setInterval(tick,1000);

const observer = new IntersectionObserver(entries=>{
  entries.forEach(entry=>{ if(entry.isIntersecting){ entry.target.classList.add('visible'); observer.unobserve(entry.target); }});
},{threshold:.12});
$$('.reveal').forEach(el=>observer.observe(el));

const bg = $('.site-bg');
window.addEventListener('scroll',()=>{
  if(!bg || window.matchMedia('(prefers-reduced-motion: reduce)').matches) return;
  bg.style.transform = `translateY(${Math.min(window.scrollY*.035,22)}px) scale(1.025)`;
},{passive:true});
